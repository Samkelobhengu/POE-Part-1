﻿using System;
using System.IO;

class AsciiImage
{
    public static void Display()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;

        string path = "Assets/bot art.txt"; // Path to ASCII file

        if (File.Exists(path))
        {
            Console.WriteLine(File.ReadAllText(path)); // Read and display ASCII image
        }
        else
        {
            Console.WriteLine("ASCII image file not found."); // Error message
        }

        Console.ResetColor();
    }
}