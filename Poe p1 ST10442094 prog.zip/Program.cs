﻿using System;

class Program
{
    static void Main()
    {
        Console.Clear();
        Logo.Display();    // Show the logo
        AsciiImage.Display(); // Show the ASCII image
        Bot.Start();       // Start chatbot
    }
}