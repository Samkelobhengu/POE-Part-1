﻿using System;
using System.IO;

class Logo
    {
        public static void Display()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;

        string path = "Assets/logo art.txt"; // Path to the logo file

        if (File.Exists(path))
        {
            Console.WriteLine(File.ReadAllText(path)); // Reading and displayment the logo 
        }
        else
        {
            Console.WriteLine("Logo file not found."); // Error message
        }

        Console.ResetColor();
    }
}