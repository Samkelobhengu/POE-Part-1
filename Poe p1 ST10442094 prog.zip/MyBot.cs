﻿using System;
using System.Media; // For playing WAV file

class Bot
{
    public static void Start()
    {
        PlayGreeting();
        Console.Write("\nEnter your name: ");
        string name = Console.ReadLine();

        Console.WriteLine($"\nWelcome, {name}! I'm All Seeing Bot, your cybersecurity assistant.");
        Console.WriteLine("You can ask me about online safety, passwords, phishing, and more.");

        while (true)
        {
            Console.Write("\nYou: ");
            string input = Console.ReadLine().ToLower();

            if (string.IsNullOrWhiteSpace(input))
            {
                Console.WriteLine("Bot: Question Please enter a valid question.");
                continue;
            }

            if (input.Contains("how are you doing roday"))
            {
                Console.WriteLine("Bot: I'm just a bot, but I'm always ready to help!");
            }
            else if (input.Contains("password"))
            {
                Console.WriteLine("Bot: A vey strong password should be at least 12 characters long and include numbers, symbols, and uppercase/lowercase letters.");
            }
            else if (input.Contains("phishing"))
            {
                Console.WriteLine("Bot: Phishing is when scammers try to trick you into giving personal information. Never click on suspicious links!");
            }
            else if (input.Contains("exit"))
            {
                Console.WriteLine("Bot: Goodbye! Stay safe online.");
                break;
            }
            else
            {
                Console.WriteLine("Bot: Hmm, I’m not sure about that. Try asking about passwords, phishing, or online safety.");
            }
        }
    }

    private static void PlayGreeting()``
    {
        string path = "Assets/CyberSecurity.wav"; //original partpathway

        if (System.IO.File.Exists(path))
        {
            SoundPlayer player = new SoundPlayer(path);
            player.Play();
        }
        else
        {
            Console.WriteLine("Bot: (Missing voice greeting) Hello! Welcome to the Cybersecurity Awareness Bot.");
        }
    }
}